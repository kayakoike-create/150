# 書く150・観る150

脚本150時間・映画150本の年間達成度を記録するミニWebアプリです。

## GitHub Pagesで公開する方法

1. GitHubで新しいリポジトリを作成
2. このフォルダの `index.html` をアップロード
3. Settings → Pages
4. Source を `Deploy from a branch` にする
5. Branch を `main` / `/root` にして Save
6. 表示されたURLをiPhoneのSafariで開く
7. 共有ボタン → ホーム画面に追加

## 注意

記録データはブラウザのlocalStorageに保存されます。
同じ端末・同じブラウザ・同じURLで使い続けるのがおすすめです。
